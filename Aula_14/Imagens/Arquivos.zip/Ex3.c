#include<stdio.h>
#include<stdlib.h>

int main(){

float nt;

printf("\n Qual foi a m�dia final do aluno?: ");
scanf("%f", &nt);

if(nt >= 7){
    printf("\n APROVADO!!!");
}

if(nt <= 5){
    printf("\n REPROVADO!!!");
}

if(nt >= 5.1 && nt <= 6.9){
    printf("\n RECUPERACAO!!!");
}


return 0;

}
