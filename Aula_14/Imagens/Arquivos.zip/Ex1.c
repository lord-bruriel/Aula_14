#include<stdio.h>
#include<stdlib.h>

int main(){

float n1 = 0, n2 = 0;

printf("\nDigite o primeiro numero: ");
scanf("%f", &n1);

printf("\nDigite o segundo numero: ");
scanf("%f", &n2);

if(n1 > n2){
    printf("\nN1 eh maior que N2!!!");
}

else if(n2 > n1){
    printf("\nN2 eh maior que N1!!!");
}

else{
    printf("\nOs numeros sao iguais!!!");
}

    return 0;

}
