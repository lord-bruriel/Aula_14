#include<stdio.h>
#include<stdlib.h>

int main(){

int an, nas, idd;

printf("\n Em que ano estamos?: ");
scanf("%d", &an);

printf("\n Em que ano voce nasceu?: ");
scanf("%d", &nas);

idd = an - nas;

printf("\n Voce tem (ou ira fazer) %d anos este ano", idd);

return 0;

}
