#include<stdio.h>
#include<stdlib.h>

int main(){

int n1 = 0, n2 = 0, n3 = 0;

printf("\nDigite o primeiro numero: ");
scanf("%d", &n1);

printf("\nDigite o segundo numero: ");
scanf("%d", &n2);

printf("\nDigite o terceiro numero: ");
scanf("%d", &n3);

if(n1 > n2 && n1 > n3){
    printf("\nN1 eh o maior numero!!!");
}

if(n2 > n1 && n2 > n3){
    printf("\nN2 eh o maior numero!!!");
}

if(n3 > n1 && n3 > n2){
    printf("\nN3 eh o maior numero!!!");
}

    return 0;

}
